import React from 'react';
import Todo from './components/Todo';
import Parent from './components/Parent';
import Child from './components/child';
import EventDemo from './components/EventDemo';
import FormValidation from './components/FormValidation';
import HooksDemo from './components/HookeDemo';

const App = () => {
  return (
    <div>
      {/* <h1>Todo Application</h1> */}
      {/* <Todo /> */}
      {/* <Parent/> */}
      {/* <EventDemo/> */}
      {/* <FormValidation/> */}
      <HooksDemo/>
    </div>
  );
};

export default App;

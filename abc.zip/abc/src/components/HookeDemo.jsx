import React, { useState, useEffect } from 'react';

const HooksDemo = () => {
const [count, setCount] = useState(0); // useState to manage count
useEffect(() => {
console.log(`Count changed to: ${count}`);
}, [count]);
return (
<div>
<h1>React Hooks Demo</h1>
<p>Current Count: {count}</p>
<button onClick={() => setCount(count + 1)}>Increase Count</button>
</div>
);
};

export default HooksDemo;
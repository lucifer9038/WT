import React, { useState } from 'react';

const Todo = () => {
  const [count, setCount] = useState(0);
  const [input, setInput] = useState('');
  const tasks = ["task1", "task2", "task3"];

  function handleClick() {
    setCount(count + 1);
  }

  function handleChange(event) {
    setInput(event.target.value);
  }

  return (
    <div>
      <h1>{count}</h1>
      <input type='text' onChange={handleChange} />
      <button onClick={handleClick} className='btn' value='addtask'>Add Task</button>
      <h1>{input}</h1>
      <h2>
        <ul>
          {tasks.map((task, index) => (
            <li key={index}>{task}</li>
          ))}
        </ul>
      </h2>
    </div>
  );
};

export default Todo;

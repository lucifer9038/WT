import React, { useState } from 'react';

const EventDemo = () => {
  const [inputValue, setInputValue] = useState('');
  const [submittedValue, setSubmittedValue] = useState('');

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleButtonClick = () => {
    alert(`Button clicked! Current input: ${inputValue}`);
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    setSubmittedValue(inputValue);
    setInputValue('');
  };

  return (
    <div>
      <h1>React Event Handling Example</h1>
      <div>
        <h3>Input Change Example</h3>
        <input
          type="text"
          value={inputValue}
          onChange={handleInputChange}
          placeholder="Type something..."
        />
        <p>Current Input: {inputValue}</p>
      </div>
      <div>
        <h3>Form Submission Example</h3>
        <form onSubmit={handleFormSubmit}>
          <input
            type="text"
            value={inputValue}
            onChange={handleInputChange}
            placeholder="Enter a value"
          />
          <button type="submit">Submit</button>
        </form>
        {submittedValue && <p>Submitted Value: {submittedValue}</p>}
      </div>
    </div>
  );
};

export default EventDemo;